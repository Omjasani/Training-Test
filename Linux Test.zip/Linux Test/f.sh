#!/bin/sh

for i in $(find *)
do
 	echo "|-- ${i}"
done
